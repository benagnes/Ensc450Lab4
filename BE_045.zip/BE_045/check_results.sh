grep --color=always "Instances:" results/summary/*

grep --color=always "Standard cells" results/summary/*.rpt

grep --color=always "Chip Density" results/summary/*.rpt

